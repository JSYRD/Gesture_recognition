namespace PKHeX.Core
{
    public enum EncounterOrder
    {
        Egg,
        Mystery,
        Static,
        Trade,
        Slot,
    }
}
