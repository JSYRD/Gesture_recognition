﻿namespace PKHeX.Core
{
    public interface IFixedAbilityNumber
    {
        AbilityPermission Ability { get; }
    }
}
