﻿namespace PKHeX.Core
{
    public interface IFixedBall
    {
        Ball FixedBall { get; }
    }
}
