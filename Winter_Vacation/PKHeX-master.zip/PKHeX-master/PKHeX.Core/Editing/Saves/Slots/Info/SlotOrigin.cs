﻿namespace PKHeX.Core
{
    public enum SlotOrigin
    {
        Party = 0,
        Box = 1,
    }
}
