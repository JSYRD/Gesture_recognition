﻿namespace PKHeX.Core
{
    public enum StorageSlotType
    {
        Box,
        Party,
        BattleBox,
        Daycare,
        GTS,
        Fused,
        Misc,
        Resort,
    }
}
