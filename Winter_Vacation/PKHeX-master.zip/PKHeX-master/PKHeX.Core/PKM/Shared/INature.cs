﻿namespace PKHeX.Core
{
    public interface INature
    {
        int Nature { get; set; }
    }
}