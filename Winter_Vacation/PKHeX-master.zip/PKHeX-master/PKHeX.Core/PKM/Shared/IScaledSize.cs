﻿namespace PKHeX.Core
{
    public interface IScaledSize
    {
        int WeightScalar { get; set; }
        int HeightScalar { get; set; }
    }
}