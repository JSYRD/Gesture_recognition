﻿namespace PKHeX.Core
{
    public interface ICaughtData2
    {
        int CaughtData { get; set; }
        int Met_TimeOfDay { get; set; }
        int Met_Level { get; set; }
        int OT_Gender { get; set; }
        int Met_Location { get; set; }
    }
}
