﻿namespace PKHeX.Core
{
    public interface IHandlerLanguage
    {
        int HT_Language { get; set; }
    }
}