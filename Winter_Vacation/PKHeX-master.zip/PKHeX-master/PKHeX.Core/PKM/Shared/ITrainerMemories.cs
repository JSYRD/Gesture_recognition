﻿namespace PKHeX.Core
{
    public interface ITrainerMemories : IMemoryOT, IMemoryHT
    {
    }
}
